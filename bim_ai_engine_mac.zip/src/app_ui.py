"""
app_ui.py — Enterprise Client Interface
----------------------------------------
Firms download this. They enter their API key once.
They process unlimited IFC files forever.
Software gets smarter automatically as you train.
"""

import streamlit as st
import requests
import time
from pathlib import Path

st.set_page_config(
    page_title="BIM AI Engine — Enterprise",
    page_icon="📐",
    layout="wide"
)

st.markdown("""
<style>
    body, .stApp { background-color: #0a0c10; color: #e2e8f0; }
    section[data-testid="stSidebar"] { background-color: #111318; }
    div.stButton > button {
        background: linear-gradient(135deg, #10b981, #059669);
        color: white; border: none; border-radius: 8px;
        padding: 14px 0; font-size: 16px; font-weight: bold;
        width: 100%; cursor: pointer;
    }
    div.stButton > button:hover { background: #059669; }
</style>
""", unsafe_allow_html=True)

# ── API Key Entry ─────────────────────────────────────────────────────────────
if "api_key" not in st.session_state:
    st.session_state["api_key"] = ""

if "authenticated" not in st.session_state:
    st.session_state["authenticated"] = False

BACKEND = st.secrets.get("BACKEND_URL", "http://127.0.0.1:8000")


def check_api_key(key: str) -> bool:
    try:
        r = requests.get(
            f"{BACKEND}/health",
            headers={"x-api-key": key},
            timeout=5
        )
        return r.status_code == 200
    except Exception:
        return False


# ── Login Screen ──────────────────────────────────────────────────────────────
if not st.session_state["authenticated"]:
    st.markdown("# 📐 BIM AI Blueprint Engine")
    st.markdown("### Enterprise Edition")
    st.markdown("---")

    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown("#### Enter Your Enterprise API Key")
        key_input = st.text_input(
            "API Key",
            type="password",
            placeholder="bim_xxxxxxxxxxxxxxxx",
            help="Contact vivaan@bim-ai.com to get your enterprise key"
        )

        if st.button("Activate License"):
            if key_input.startswith("bim_"):
                with st.spinner("Verifying license..."):
                    if check_api_key(key_input):
                        st.session_state["api_key"]       = key_input
                        st.session_state["authenticated"] = True
                        st.rerun()
                    else:
                        st.error("Invalid key or server offline.")
            else:
                st.error("Keys start with 'bim_' — check your key and try again.")

        st.markdown("---")
        st.caption("Need a license? Email vivaan@bim-ai.com")

else:
    # ── Main App ──────────────────────────────────────────────────────────────
    API_KEY = st.session_state["api_key"]
    HEADERS = {"x-api-key": API_KEY}

    with st.sidebar:
        st.markdown("## 📐 BIM AI Engine")
        st.markdown("**Enterprise Edition**")
        st.markdown("---")

        try:
            r = requests.get(f"{BACKEND}/health", timeout=3)
            if r.status_code == 200:
                st.success("● Server Online")
        except Exception:
            st.error("● Server Offline")

        model_path = Path("models/drafting_ai.pth")
        if model_path.exists():
            st.success("● AI Model Active")
        else:
            st.info("● Geometric Mode")

        st.markdown("---")
        st.markdown("### Recent Output")
        output_dir = Path("../output")
        if output_dir.exists():
            files = sorted(
                output_dir.glob("*"),
                key=lambda f: f.stat().st_mtime,
                reverse=True
            )[:5]
            for f in files:
                st.caption(f"📄 {f.name}")

        st.markdown("---")
        if st.button("Sign Out"):
            st.session_state["authenticated"] = False
            st.session_state["api_key"]       = ""
            st.rerun()

    st.markdown("# 📐 BIM AI Blueprint Engine")
    st.markdown("Convert any 3D IFC building model into production drawings instantly.")
    st.markdown("---")

    left, right = st.columns([1, 1])

    with left:
        st.markdown("### Upload Building Model")
        uploaded = st.file_uploader(
            "Drag & drop your .IFC file",
            type=["ifc"]
        )

        if uploaded:
            size_mb = len(uploaded.getvalue()) / (1024 * 1024)
            st.success(f"Loaded: {uploaded.name} ({size_mb:.1f} MB)")

            if st.button("🚀 Process Building"):
                progress = st.progress(0)
                status   = st.empty()

                try:
                    status.markdown("`Uploading to AI engine...`")
                    progress.progress(10)

                    response = requests.post(
                        f"{BACKEND}/process-bim-model",
                        files={"file": (
                            uploaded.name,
                            uploaded.getvalue(),
                            "application/octet-stream"
                        )},
                        headers=HEADERS,
                        timeout=300
                    )

                    status.markdown("`Extracting wall geometry...`")
                    progress.progress(35)
                    time.sleep(0.3)
                    status.markdown("`Running AI annotation inference...`")
                    progress.progress(60)
                    time.sleep(0.3)
                    status.markdown("`Collision avoidance pass...`")
                    progress.progress(80)
                    time.sleep(0.3)
                    status.markdown("`Compiling production DXF...`")
                    progress.progress(95)
                    time.sleep(0.2)

                    if response.status_code == 200:
                        data = response.json()

                        if data.get("status") == "Success":
                            progress.progress(100)
                            status.markdown("`Complete.`")

                            st.session_state["result"]     = data
                            st.session_state["job_done"]   = True
                            st.toast("Processing complete!", icon="✅")

                        elif response.status_code == 401:
                            st.error("API key rejected. Contact support.")
                        else:
                            st.error(f"Failed: {data.get('error_log')}")
                    else:
                        st.error(f"Server error: {response.status_code}")

                except requests.exceptions.Timeout:
                    st.error("Timed out. Very large files take up to 5 minutes.")
                except Exception as e:
                    st.error(f"Error: {e}")

    with right:
        st.markdown("### Output Files")

        if st.session_state.get("job_done"):
            data = st.session_state["result"]

            m1, m2 = st.columns(2)
            m1.metric("Walls Extracted", data.get("wall_count", "—"))
            m2.metric("Files Ready", "2")

            st.markdown("---")

            dxf_name = Path(data.get("dxf_blueprint", "")).name
            csv_name = Path(data.get("csv_schedule", "")).name

            # DXF Download
            try:
                dxf_r = requests.get(
                    f"{BACKEND}/output/{dxf_name}",
                    headers=HEADERS,
                    timeout=60
                )
                if dxf_r.status_code == 200:
                    st.download_button(
                        "📐 Download DXF Blueprint",
                        data=dxf_r.content,
                        file_name=dxf_name,
                        mime="application/octet-stream",
                        use_container_width=True
                    )
            except Exception:
                st.info(f"DXF saved to: output/{dxf_name}")

            # CSV Download
            try:
                csv_r = requests.get(
                    f"{BACKEND}/output/{csv_name}",
                    headers=HEADERS,
                    timeout=60
                )
                if csv_r.status_code == 200:
                    st.download_button(
                        "📊 Download Door Schedule",
                        data=csv_r.content,
                        file_name=csv_name,
                        mime="text/csv",
                        use_container_width=True
                    )
            except Exception:
                st.info(f"CSV saved to: output/{csv_name}")

        else:
            st.info("Upload a file and run the pipeline to see output here.")